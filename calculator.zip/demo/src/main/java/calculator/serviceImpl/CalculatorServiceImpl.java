package calculator.serviceImpl;

import calculator.service.CalculatorService;
import org.springframework.stereotype.Service;

@Service
public class CalculatorServiceImpl implements CalculatorService {


  @Override
  public Long getAddition(Long value1, Long value2) {
    return value1+value2;
  }//close getAddition method

  @Override
  public Long getSubtraction(Long value1, Long value2) {
    return value1-value2;
  }//close getAddition method

  @Override
  public Long getMultiplication(Long value1, Long value2) {
    return value1*value2;
  }//close getAddition method

  @Override
  public Long getDivision(Long value1, Long value2) {
    return value1/value2;
  }//close getAddition method
}
