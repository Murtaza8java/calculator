package calculator.service;

public interface CalculatorService {


  Long getAddition(Long value1,Long value2);
  Long getSubtraction(Long value1,Long value2);
  Long getMultiplication(Long value1,Long value2);
  Long getDivision(Long value1,Long value2);
}
