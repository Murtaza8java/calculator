package calculator.controller;

import calculator.dto.RequestValuesDTO;
import calculator.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.text.SimpleDateFormat;
import java.util.*;


@RestController
@RequestMapping("/calculator")
public class CalculatorController {


  @Autowired
  private CalculatorService calculatorService;

  @GetMapping("/addition")
  public ResponseEntity<String> addition(@ModelAttribute RequestValuesDTO requestValuesDTO) {
    try {

        if (requestValuesDTO != null && requestValuesDTO.getValue1()!=null && requestValuesDTO.getValue2()!=null ) {

          Long sum =calculatorService.getAddition(requestValuesDTO.getValue1(),requestValuesDTO.getValue2());
          return new ResponseEntity<>("sum : " + sum, HttpStatus.OK);

        } else
               return  new ResponseEntity<>("all fields must not be null ", HttpStatus.BAD_REQUEST);

    }catch (Exception e) {
      e.printStackTrace();
      return  new ResponseEntity<>("something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }//close addition

  @GetMapping("/subtraction")
  public ResponseEntity<String> subtraction(@ModelAttribute RequestValuesDTO requestValuesDTO) {
    try {
        if(requestValuesDTO != null && requestValuesDTO.getValue1()!=null && requestValuesDTO.getValue2()!=null ) {

          Long sum =calculatorService.getSubtraction(requestValuesDTO.getValue1(),requestValuesDTO.getValue2());
          return new ResponseEntity<>("sum : " + sum, HttpStatus.OK);

        }  else
          return  new ResponseEntity<>("all fields must not be null ", HttpStatus.BAD_REQUEST);

    }catch (Exception e) {
      e.printStackTrace();
      return  new ResponseEntity<>("something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }//close addition

  @GetMapping("/multiplication")
  public ResponseEntity<String> multiplication(@ModelAttribute RequestValuesDTO requestValuesDTO) {
    try{
        if(requestValuesDTO != null && requestValuesDTO.getValue1()!=null && requestValuesDTO.getValue2()!=null ) {

            Long sum =calculatorService.getMultiplication(requestValuesDTO.getValue1(),requestValuesDTO.getValue2());
            return new ResponseEntity<>("sum : " + sum, HttpStatus.OK);

        } else
            return  new ResponseEntity<>("all fields must not be null ", HttpStatus.BAD_REQUEST);

    }catch (ArithmeticException ae) {
      ae.printStackTrace();
      return  new ResponseEntity<>("both numbers must not be zero ", HttpStatus.INTERNAL_SERVER_ERROR);
    }
    catch (Exception e) {
      e.printStackTrace();
      return  new ResponseEntity<>("something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }//close addition

  @GetMapping("/division")
  public ResponseEntity<String> division(@ModelAttribute RequestValuesDTO requestValuesDTO) {
    try{
        if(requestValuesDTO != null && requestValuesDTO.getValue1()!=null && requestValuesDTO.getValue2()!=null ) {

          Long sum =calculatorService.getDivision(requestValuesDTO.getValue1(),requestValuesDTO.getValue2());
          return new ResponseEntity<>("sum : " + sum, HttpStatus.OK);

        } else
          return  new ResponseEntity<>("all fields must not be null ", HttpStatus.BAD_REQUEST);

    }catch (ArithmeticException ae) {
      ae.printStackTrace();
      return  new ResponseEntity<>("both numbers must not be zero ", HttpStatus.INTERNAL_SERVER_ERROR);
    }
    catch (Exception e) {
      e.printStackTrace();
      return  new ResponseEntity<>("something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }//close addition

}

