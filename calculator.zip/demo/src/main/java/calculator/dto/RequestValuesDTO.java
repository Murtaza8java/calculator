package calculator.dto;


import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@ToString
@Data
public class RequestValuesDTO {

  private Long value1;
  private Long value2;

}
